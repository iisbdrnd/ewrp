{!! $projectLists !!}
<script>
$('#mobilizeActivityBlade').show();
$('#mobilizingRoom').hide();
</script>