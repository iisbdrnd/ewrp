<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: 100%; height: auto;">
    <div class="table-responsive" style="overflow: hidden; width: 100%; height: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th class="per5">#</th>
                    <th class="per40">Trade</th>
                    <th class="per40">No. of Candidates</th>
                </tr>
            </thead>
            <tbody>
                @foreach($selectedTrades as $index => $selectedTrade)
                <tr>
                    <td>{{$index + 1}}</td>
                    <td>{{$selectedTrade->trade_name}}</td>
                    <td>{{@Helper::noOfCandidates($projectId, $selectedTrade->id)}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="slimScrollBar ui-draggable"
        style="background: rgb(243, 243, 243); height: 5px; position: absolute; bottom: 3px; opacity: 0.4; display: none; border-radius: 5px; z-index: 99; width: 508px; left: 0px;">
    </div>
    <div class="slimScrollRail"
        style="width: 100%; height: 5px; position: absolute; bottom: 3px; display: none; border-radius: 5px; background: rgb(51, 51, 51); opacity: 0.3; z-index: 90;">
    </div>
</div>