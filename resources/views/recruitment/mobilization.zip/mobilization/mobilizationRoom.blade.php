@include("urlParaMeter")
<?php $tableTitle = @Helper::projects($projectId)->project_name; $loadUrl = "mobilizationRoomData?projectId=".$projectId."&"."projectCountryId=".$projectCountryId; ?>
@include("dataListFrame")
<div style="display: none;" id="panelId">
<?php $panelTitle ="Mobilization"; $refreshUrl=""; $panelId="panelId";?>
@include("panelStart")
<div id="mobilizeTemplate" class="data-list"></div>
@include("panelEnd")
</div>
{{-- This element value are cought from mobilizationRoomCandidateData blade --}}
<input type="hidden" id="mobilizeId">
<input type="hidden" id="projectId" value="{{ $projectId }}">
<input type="hidden" id="mobilizeName">

<script type="text/javascript"> 
$('.heading h3').text('Mobilization');
	function totalCandidates(){
		var candidateIds = $('#total_candidate').attr('candidate-data');
	}

	function mobilizeCandidateList(mobilizeId, i) {
		console.log(mobilizeId);
		var nextMobilizeId = $('.getMobilizeNameById2').attr('nextMobilizeId');

		$('#mobilizeId').val(mobilizeId);
		let mobilizeName = $('.mobilizeName'+mobilizeId).text();
		$('#mobilizeName').val(mobilizeName);
	
		current      = $('#currentId'+i).attr('currentAttr');

    if (mobilizeId == 'candidates') {
			$('.panel-title').text("Selection List").css({'color':'red'});
		}

    if (mobilizeId == 'finalizing') {
    $('.panel-title').text("Finalizing List").css({'color':'red'});
    }

		let url          = '{{ url('recruitment/mobilization/mobilizationRoomCandidateData/'.$projectId) }}/{{$projectCountryId}}/'+mobilizeId+'/'+current;
		let refreshUrl   = '{{ 'mobilization/mobilizationRoomCandidateData/'.$projectId }}/{{$projectCountryId}}/'+mobilizeId+'/'+current;
		
	function filteration(){
		$('.mobilizeFiltering').on('click', function(){
			console.log($(this).attr('data'));
			let filterData = $(this).attr('data');
			let url        = '{{ url('recruitment/mobilization/mobilizationRoomCandidateData/'.$projectId) }}/{{$projectCountryId}}/'+mobilizeId+'/'+filterData;
			let refreshUrl = '{{ 'mobilization/mobilizationRoomCandidateData/'.$projectId }}/{{$projectCountryId}}/{{$projectCountryId}}/'+mobilizeId+'/'+filterData;
		    $.ajax({
				mimeType: 'text/html; charset=utf-8',
				type: 'GET',
				url:url,
				data: {'mobilizeId':mobilizeId},
				processData: false,
				contentType: false,
				success: function(data){
				$('#mobilizeTemplate').load(url, filteration);
				$('#panelId').attr('refresh-url', refreshUrl);
				$('#panelId').show();
			
					if(filterData == 1){
						$('#mobilizeFiltering').prop('selected', true);
					}else{
						$('#mobilizeFiltering').prop('selected', true);	
					}
				}
			});
		});
	}
		$.ajax({
			mimeType: 'text/html; charset=utf-8',
			type: 'GET',
			url:url,
			data: {'mobilizeId':mobilizeId},
			processData: false,
			contentType: false,
			success: function(data){
			$('#mobilizeTemplate').load(url, filteration);
			$('#panelId').attr('refresh-url', refreshUrl);
			$('#panelId').show();
			}
		});
	}

 function hideMobilizeList(){
 	$('#panelId').hide();	
 }

	function lateCandidateList(mobilizeId, i) {
		var late       = $('#lateId'+i).attr('lateAttr');
		let url        = '{{ url('recruitment/mobilization/mobilizationRoomCandidateData/'.$projectId) }}/'+mobilizeId+'/'+late;
		let refreshUrl = '{{ 'mobilization/mobilizationRoomCandidateData/'.$projectId }}/'+mobilizeId+'/'+late;
		
		function filteration(){
		$('#mobilizeFiltering').on('change', function(){
			let filterData = $(this).val();
			let url        = '{{ url('recruitment/mobilization/mobilizationRoomCandidateData/'.$projectId) }}/'+mobilizeId+'/'+filterData;
			let refreshUrl = '{{ 'mobilization/mobilizationRoomCandidateData/'.$projectId }}/'+mobilizeId+'/'+filterData;

		    $.ajax({
				mimeType: 'text/html; charset=utf-8',
				type: 'GET',
				url:url,
				data: {'mobilizeId':mobilizeId},
				processData: false,
				contentType: false,
				success: function(data){
				$('#mobilizeTemplate').load(url, filteration);
				$('#panelId').attr('refresh-url', refreshUrl);
				$('#panelId').show();
				}
			});
		});
	}

		$.ajax({
			mimeType: 'text/html; charset=utf-8',
			type: 'GET',
			url:url,
			data: {'mobilizeId':mobilizeId},
			processData: false,
			contentType: false,
			success: function(data){
			$('#mobilizeTemplate').load(url, filteration);
			$('#panelId').attr('refresh-url', refreshUrl);
			$('#panelId').show();
			}
		});
	}
</script>