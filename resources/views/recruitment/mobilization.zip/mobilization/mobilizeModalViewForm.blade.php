<style>
body {position:relative;}
.bootstrap-datetimepicker-widget {z-index: 9999 !important;}
</style>
<form class="form-horizontal" id="mobilizeFormData" method="post" action="">
  {{csrf_field()}}
  <input type="hidden" name="projectId" class="projectId">
  <input type="hidden" name="candidateId" class="candidateId">
  <input type="hidden" name="mobilizeId" class="mobilizeId">
  <div class="panel panel-default chart"> 
    <div class="panel-body">
      <!-- MEDICAL OR MEDICAL FIT/UNFIT START-->
      <div class="form-group medicalStatus medical_name">
        <label class="col-lg-3 col-md-4 control-label medicalName">Medical Name</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_name" class="form-control" id="medical_name" placeholder="e.g. Dhaka Medical">
        </div>
      </div>
      <div class="form-group medicalStatus medical_gone_date">
        <label class="col-lg-3 col-md-4 control-label dateTimeFormat medicalDate">Medical Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_gone_date" id="medical_gone_date" value="{{ date('m-d-Y') }}" class="form-control dateTimeFormat keypressOff"
            placeholder="e.g. dd-mm-yyyy">
        </div>
      </div>
      <div class="form-group medicalStatus medical_code">
        <label class="col-lg-3 col-md-4 control-label medicalCode">Medical Code</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_code" id="medical_code" class="form-control" placeholder="e.g. 764-783">
        </div>
      </div>
      <div class="form-group medicalStatus medical_status">
        <label class="col-lg-3 col-md-4 control-label medicalStatus">Medical Status</label>
        <div class="col-lg-7 col-md-6">
          <select name="medical_actual_status" id="medical_actual_status" class=" form-control">
            <option value="0">---Select Status---</option>
            <option value="1">Fit</option>
            <option value="2">Unfit</option>
            <option value="3">Remedical</option>
            <option value="4">Fit Self</option>
          </select>
        </div>
      </div>
      {{-- <div class="form-group medicalOnline">
        <label class="col-lg-3 col-md-4 control-label dateTimeFormat">Medical Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_online_date" id="medical_online_date" value="{{ date('m-d-Y') }}" class="form-control dateTimeFormat keypressOff"
            placeholder="e.g. dd-mm-yyyy">
        </div>
      </div> --}}
      <!--Medical Slip --->
      <div class="form-group medicalSlip">
        <label class="col-lg-3 col-md-4 control-label medicalName">Medical Center</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_name_in_slip" class="form-control" id="medical_name_in_slip" placeholder="e.g. Dhaka Medical">
        </div>
      </div>
      <div class="form-group medicalSlip">
        <label class="col-lg-3 col-md-4 control-label">Medical Slip No.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_slip_no" id="medical_slip_no" class="form-control" placeholder="e.g. 764-783">
        </div>
      </div>
      <div class="form-group medicalSlip">
        <label class="col-lg-3 col-md-4 control-label">Report Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_slip_date" id="medical_slip_date" value="{{ date('d-m-Y') }}" class="form-control dateTimeFormat keypressOff"
            placeholder="dd-mm-yyyy">
        </div>
      </div>
      <div class="form-group medicalSlip">
        <label class="col-lg-3 col-md-4 control-label">Passport Status</label>
        <div class="col-lg-7 col-md-6">
          <select name="medical_slip_status" id="medical_slip_status" class="form-control">
            <option>--Passport Status---</option>
            <option value="1">Yes</option>
            <option value="2">No</option>
          </select>
        </div>
      </div>
      <!--- Medical Slip End-->

      <!--- MEDICAL CALL START-->
      <div class="form-group medicalCall">
        <label class="col-lg-3 col-md-4 control-label">Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="medical_call_date"  class="form-control dateTimeFormat keypressOff" id="medical_call_date" value="{{ date('d-m-Y') }}"
            placeholder="e.g.dd-mm-yyyy">
        </div>
      </div>
      <div class="form-group medicalCall">
        <label class="col-lg-3 col-md-4 control-label">Remarks</label>
        <div class="col-lg-7 col-md-6">
          <textarea name="medical_call_remarks" id="medical_call_remarks" class="form-control" cols="3" rows="5"></textarea>
        </div>
      </div>
      {{-- <div class="form-group medicalCall">
        <label class="col-lg-3 col-md-3 control-label">GTC Sent</label>
        <div class="col-lg-1 col-md-1 pull-left">
          <input type="checkbox" name="gtc_sent" value="1" class="form-control" id="gtc_sent">
        </div>
        <div id="gtc_serial_number" style="display:none;">
          <div class="col-lg-4 col-md-4  text-left">
            <input type="text" name="gttc_serial_numbers" id="gttc_serial_numbers" class="form-control" placeholder="GTC Serial number e.g. 1463009">
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
              </span>
              <input id="gttc_dates" name="gttc_dates" class="form-control dateTimeFormat keypressOff" placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
            </div>
          </div>
        </div>
      </div>
      <div class="form-group medicalCall">
        <label class="col-lg-3 col-md-3 control-label">PCC Sent</label>
        <div class="col-lg-1 col-md-1  text-left">
          <input type="checkbox" name="pcc_sent" value="1" class="form-control" id="pcc_sent">
        </div>
        <div id="pcc_serial_number" style="display:none;">
          <div class="col-lg-4 col-md-4  text-left">
            <input type="text" name="pcc_serial_numbers" id="pcc_serial_numbers" class="form-control" placeholder="PCC Serial number e.g. 1463009">
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
              </span>
              <input id="pcc_dates" name="pcc_dates" class="form-control dateTimeFormat keypressOff" placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
            </div>
          </div>
        </div>

      </div> --}}
      <!-- MEDICAL CALL END-->

      <!-- MEDICAL SENT START-->
      <div class="form-group medicalSent">
        <label class="col-lg-3 col-md-4 control-label">Medical Sent Date</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="medical_sent_date" name="medical_sent_date" class="form-control dateTimeFormat keypressOff"
              placeholder="dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      {{-- <div class="medicalSent">
      <div class="form-group">
        <label class="col-lg-3 col-md-3 control-label">Medical Slip</label>
        <div class="col-lg-1 col-md-1 pull-left">
        <input type="checkbox" name="medical_slip" value="1" class="form-control checkbox" id="medical_slip">
        </div>
      </div>
        <div class=" medical_slip_show" style="display:none;">
        <div class="form-group">
            <label class="col-lg-3 col-md-4 control-label medicalName">Medical Center</label>
            <div class="col-lg-7 col-md-6">
              <input type="text" name="medical_center_name_for_slip" class="form-control" id="medical_center_name_for_slip" placeholder="e.g. Dhaka Medical">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 col-md-4 control-label">Medical Slip No.</label>
            <div class="col-lg-7 col-md-6">
              <input type="text" name="medicla_no_for_slip" id="medicla_no_for_slip" class="form-control" placeholder="e.g. 764-783">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 col-md-4 control-label">Report Date</label>
            <div class="col-lg-7 col-md-6">
              <input type="text" name="medical_date_for_slip" id="medical_date_for_slip" value="{{ date('d-m-Y') }}" class="form-control dateTimeFormat keypressOff"
                placeholder="dd-mm-yyyy">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 col-md-4 control-label">Status</label>
            <div class="col-lg-7 col-md-6">
              <select name="medical_status_for_slip" id="medical_status_for_slip" class="form-control">
                <option>---Select Status---</option>
                <option value="1">Yes</option>
                <option value="2">No</option>
              </select>
            </div>
          </div>
        </div>
      </div> --}}
      <!-- MEDICAL SENT END-->
      <!--PCC SENT START-->
      <div class="form-group pccSent">
        <label class="col-lg-3 col-md-4 control-label">PCC Serial No.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="pcc_serial_number" id="pcc_serial_number" class="form-control" placeholder="PCC Serial number e.g. 1463009">
        </div>
      </div>
      <div class="form-group pccSent">
        <label class="col-lg-3 col-md-4 control-label">Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="pcc_date" class="form-control dateTimeFormat keypressOff" id="pcc_date" placeholder="e.g.dd-mm-yyyy" value="{{ date('d-m-Y') }}">
        </div>
      </div>
      <!--PCC SENT END-->

      <!--GTC SENT START-->
      <div class="form-group gtcSent">
        <label class="col-lg-3 col-md-4 control-label">GTC Serial No.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="gttc_serial_number" class="form-control" placeholder="GTC Serial number e.g. 1463009">
        </div>
      </div>
      <div class="form-group gtcSent">
        <label class="col-lg-3 col-md-4 control-label">Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="gttc_date" class="form-control dateTimeFormat keypressOff" id="gttc_date"
            placeholder="e.g.dd-mm-yyyy" value="{{ date('d-m-Y') }}">
        </div>
      </div>
      <!--GTC SENT END-->

      <!-- REMEDICAL START-->
      <div class="form-group remedical">
        <label class="col-lg-3 col-md-4 control-label">Medical Name</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="remedical_name" class="form-control" id="remedical_name"
            placeholder="e.g. Dhaka Medical">
        </div>
      </div>
      <div class="form-group remedical">
        <label class="col-lg-3 col-md-4 control-label">Remedical Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="remedical_date" class="form-control dateTimeFormat keypressOff" id="remedical_date"
            placeholder="e.g.dd-mm-yyyy" value="{{ date('d-m-Y') }}">
        </div>
      </div>
      <div class="form-group remedical">
        <label class="col-lg-3 col-md-4 control-label">Remedical Status</label>
        <div class="col-lg-7 col-md-6">
          <select name="remedical_actual_status" id="remedical_actual_status" class="form-control">
            <option>---Select Status---</option>
            <option value="1">Fit</option>
            <option value="2">Unfit</option>
          </select>
        </div>
      </div>
      <div class="form-group remedical">
        <label class="col-lg-3 col-md-4 control-label">Remarks</label>
        <div class="col-lg-7 col-md-6">
          <textarea name="remedical_call_remarks" id="remedical_call_remarks" class="form-control" cols="3" rows="5"></textarea>
        </div>
      </div>
      <!-- REMEDICAL END-->

      <!--PTA REQUEST START-->
      <div class="form-group ptaRequest">
        <label class="col-lg-3 col-md-4 control-label">PTA Request</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="pta_request_date" name="pta_request_date" class="form-control dateTimeFormat keypressOff"
              placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      <div class="form-group ptaRequest">
        <label class="col-lg-3 col-md-4 control-label">PTA Request Status</label>
        <div class="col-lg-7 col-md-6">
          <select name="pta_request_status" id="pta_request_status" class="form-control">
            <option value="1">Yes</option>
            <option value="2">No</option>
          </select>
        </div>
      </div>
      <div class="form-group ptaRequest">
        <label class="col-lg-3 col-md-4 control-label">Remarks</label>
        <div class="col-lg-7 col-md-6">
          <textarea name="pta_request_remarks" id="pta_request_remarks" class="form-control" cols="3" rows="5"></textarea>
        </div>
      </div>
      <!--PTA REQUEST END-->

      <!--PTA RECEIVE START-->
      <div class="form-group ptaReceive">
        <label class="col-lg-3 col-md-4 control-label">Ticket/PTA Date </label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="pta_receive_date" name="pta_receive_date" class="form-control dateTimeFormat keypressOff"
              placeholder="e.g. dd-mm-yyyy" value="{{ date('m-d-Y') }}">
          </div>
        </div>
      </div>
      <div class="form-group ptaReceive">
        <label class="col-lg-3 col-md-4 control-label">Flight Date</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="pta_flight_date" name="pta_flight_date" class="form-control dateTimeFormat keypressOff" placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      <div class="form-group ptaReceive">
        <label class="col-lg-3 col-md-4 control-label">Flight No.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="flight_no" id="flight_no" class="form-control" placeholder="e.g. 764-783">
        </div>
      </div>
      <div class="form-group ptaReceive">
        <label class="col-lg-3 col-md-4 control-label">Flight Time.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" id="time_picker" name="flight_time" id="flight_time" class="form-control time_picker" placeholder="e.g. 12:00 AM">
        </div>
      </div>
      <div class="form-group ptaReceive transit_place">
        <label class="col-lg-3 col-md-4 control-label">Transit Place</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="transit_place" id="transit_place" class="form-control" placeholder="e.g. Abu Dhabi">
        </div>
      </div>
      <!--PTA RECEIVE END-->

      <!--FLIGHT BRIEFING -->
      <div class="form-group flightNo flight_status">
          <label class="col-lg-3 col-md-4 control-label">Flight Status</label>
          <div class="col-lg-7 col-md-6">
            <select name="flight_status" id="flight_status" class="form-control" placeholder="Select Status">
              <option>--Select Status--</option>
              <option value="1">Yes</option>
              <option value="2">No</option>
            </select>
          </div>
        </div>
      <div class="form-group flightNo flight_briefing_date">
        <label class="col-lg-3 col-md-4 control-label">Briefing Date.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="flight_briefing_date" id="flight_briefing_date" class="form-control dateTimeFormat" placeholder="e.g. 21-04-2018">
        </div>
      </div>
      <div class="form-group flightNo flight_remarks">
          <label class="col-lg-3 col-md-4 control-label">Remarks</label>
          <div class="col-lg-7 col-md-6">
            <textarea name="flight_remarks" id="flight_remarks" class="form-control" cols="3" rows="5"></textarea>
          </div>
        </div>

      <!--FLIGHT NO START -->

      <!--VISA ONLINE START-->
      <div class="form-group visaOnlineGroup">
        <label class="col-lg-3 col-md-4 control-label">Visa Online Date</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input type="text" id="visa_online_date" name="visa_online_date" class="form-control dateTimeFormat keypressOff"
              placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      <div class="form-group visaOnlineGroup">
        <label class="col-lg-3 col-md-4 control-label" id="visa_status_code_label">Visa Status Code</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="visa_status_code" id="visa_status_code" placeholder="e.g.3112748" class="form-control">
        </div>
      </div>
      <div class="form-group visaOnlineGroup visaGroup">
        <label class="col-lg-3 col-md-4 control-label">Visa Issued Date</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="visa_issued_date" name="visa_issued_date" class="form-control dateTimeFormat keypressOff"
              placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      <div class="form-group visaOnlineGroup visaGroup visaExpiryDate">
        <label class="col-lg-3 col-md-4 control-label">Visa Expiry Date</label>
        <div class="col-lg-7 col-md-6">
          <div class="input-group">
            <span class="input-group-addon">
              <i class="fa fa-calendar"></i>
            </span>
            <input id="visa_expiry_date" name="visa_expiry_date" class="form-control dateTimeFormat keypressOff"
              placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
          </div>
        </div>
      </div>
      <!--VISA ONLINE END-->

      <!--OTHERS FORM START-->
      <div class="form-group othersGroup">
        <label class="col-lg-3 col-md-4 control-label">Date</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="mobilize_date" id="mobilize_date" class="form-control dateTimeFormat keypressOff" placeholder="e.g. dd-mm-yyyy" value="{{ date('d-m-Y') }}">
        </div>
      </div>
      <div class="form-group  visaPrint">
        <label class="col-lg-3 col-md-4 control-label">Visa No.</label>
        <div class="col-lg-7 col-md-6">
          <input type="text" name="visa_no" id="visa_no" class="form-control" placeholder="e.g. 945849">
        </div>
      </div>
      <!--OTHERS FORM END-->
    </div>
  </div>
</form>
<script>
  // $('.time_picker').datetimepicker({
  //          format: 'LT'
  //      });
$('#time_picker').datetimepicker({
		// locale: 'it',
		format: "LT",
		widgetParent: 'body'      //<-----IMPORTANT
	});
	
	$('#time_picker').on('dp.show', function() {
	  var datepicker = $('body').find('.bootstrap-datetimepicker-widget:last');

	  if (datepicker.hasClass('bottom')) {

		var top = $(this).offset().top + $(this).outerHeight();
		var left = $(this).offset().left;
		datepicker.css({
		  'top': top + 'px',
		  'bottom': 'auto',
		  'left': left + 'px'
		});

	  }  
    
    if (datepicker.hasClass('top')) {

		var top = $(this).offset().top - datepicker.outerHeight();
		var left = $(this).offset().left;
		datepicker.css({
		  'top': top + 'px',
		  'bottom': 'auto',
		  'left': left + 'px'
		});

	  }

	});


   /* Select2 */
   $("select.select2").select2({
    placeholder: "Select"
  });

  $('#medical_actual_status').change(function(){
    
    if (this.value == 3) {

      $('.othersGroup').show();
      
    } else {

      $('.othersGroup').hide();

    }
    
  }).trigger('change');

  $('#gtc_sent').on('change', function () {
    if (this.checked) {

      $('#gtc_serial_number').show();

    } else {

      $('#gtc_serial_number').hide();

    }
  });

  $('#pcc_sent').on('change', function () {

    if (this.checked) {

      $('#pcc_serial_number').show();

    } else {

      $('#pcc_serial_number').hide();

    }

  });

  /* MEDICAL SENT WITH MEDICAL SLIP */
  $('#medical_slip').on('change', function(){
    console.log(this.checked);

    if (this.checked) {

      $('.medical_slip_show').show();

    } else {

      $('.medical_slip_show').hide();

    }

  });
</script>