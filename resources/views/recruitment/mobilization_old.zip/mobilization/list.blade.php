@include("urlParaMeter")
<?php $tableTitle = "Mobilization Project"; $loadUrl = "mobilizationProjectListData"; ?>
@include("dataListFrame")