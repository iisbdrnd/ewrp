@include("urlParaMeter")
<?php $tableTitle ="All Notes"; $loadUrl = "activitiesSideNoteData?projectId=".$projectId."&"."candidateId=".$candidateId."&"."mobilizeId=".$mobilizeId; ?>
@include("dataListFrame")