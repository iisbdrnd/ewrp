<?php $panelTitle = "Create"; ?>
@include("panelStart")
<form type="create" id="opportunityCreateForm" panelTitle="{{$panelTitle}}" class="form-load form-horizontal" data-fv-excluded="">
</form>
@include("panelEnd")

<script type="text/javascript">
 
</script>



