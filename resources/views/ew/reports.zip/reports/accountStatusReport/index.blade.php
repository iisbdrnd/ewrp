<?php $panelTitle = "Amount Status Report"; ?>
@include("panelStart")
<form id="amountStatusReportForm" method="post" panelTitle="{{$panelTitle}}" type="view" class="form-horizontal" data-fv-excluded="">
    {{csrf_field()}}
    <div class="row mt15">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="col-lg-6 col-md-12 sortable-layout col-no-pr"><!--Left Side Box-->
                <div class="panel panel-default chart">
                    <div class="panel-body">
                        <div class=simple-chart>
                            <div class="form-group">
                                <label class="col-lg-4 col-md-4 control-label">Project</label>
                                <div class="col-lg-8 col-md-8">
                                    <select id="ew_project_id" name="project_id" data-fv-icon="false" class="select2 form-control ml0">
                                        <option value="">All Project</option>
                                        @foreach($ewProjects as $ewProjects)
                                        <option value="{{$ewProjects->id}}">{{$ewProjects->project_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 col-md-4 control-label">Candidate</label>
                                <div class="col-lg-8 col-md-8">
                                  <div id="project_candidate_id">
                                    <select name="candidate_id" id="candidate_id" data-fv-icon="false" class="select2 form-control ml0">
                                        <option value="">All Candidates</option>
                                    </select>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--CANDIDATE DETAILS RISHT SIDE BOX-->
            <div class="col-lg-6 col-md-12 sortable-layout candidateInfo">
                <div class="panel panel-default chart">
                    <div class="panel-body">
                        <div class="simple-chart" style="line-height: 25px;">
                            <div class="row">
                                <div class="col-md-3 col-sm-3 col-xs-5">Father's Name</div>
                                <div class="col-md-9 col-sm-9 col-xs-7">: <span class="fName"></span></div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3 col-xs-5">Reference</div>
                                <div class="col-md-9 col-sm-9 col-xs-7">: <span class="reference"></span></div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3 col-xs-5">Trade</div>
                                <div class="col-md-9 col-sm-9 col-xs-7">: <span class="trade"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-offset-2 col-lg-10 btn-pb15">
        <button id="preview_button" type="submit" class="btn btn-default ml8 btn-ml0">Preview</button>
    </div>
</form>
@include("panelEnd")
<script type="text/javascript">
    $(document).ready(function() {
        date_range = 0;
        $(".select2").select2({
            placeholder: "Select"
        });

        //Candidate's Account Summary
        $("#ew_project_id").on('change', function(e) {
            var ew_project_id = $(this).val();
            if (ew_project_id) {
                //For Project wise candidates
                $.ajax({
                    mimeType: 'text/html; charset=utf-8',
                    url: '{{route("ew.projectCandidates")}}',
                    data: {ew_project_id:ew_project_id},
                    type: 'GET',
                    dataType: "html",
                    success: function(data) {
                        $("#project_candidate_id").html(data);
                        $("#candidate_id").select2({ placeholder: "Select" });
                        $('#amountStatusReportForm').formValidation('addField', $('#candidate_id'));

                        $('.fName').text('');
                        $('.reference').text('');
                        $('.trade').text('');
                        $('.projectName').text('');
                    }
                });
            }
        });

        //Candidate's Details
        $("#amountStatusReportForm").on('change', '#candidate_id', function(e) {
            var projectId = $("#ew_project_id").val();
            var candidateId = $("#candidate_id").val();
            $.ajax({
                mimeType: 'text/html; charset=utf-8',
                url: '{{route("ew.candidate-sort-details")}}',
                data: {projectId:projectId, candidateId:candidateId},
                type: 'GET',
                dataType: "json",
                success: function(data) {
                    $('.fName').text(data.candidate_details.father_name);
                    $('.reference').text(data.candidate_details.reference_name);
                    $('.trade').text(data.candidate_details.trade_name);
                    $('.projectName').text(data.candidate_details.project_name);
                }
            });
        });


        $("#amountStatusReportForm").formValidation().on('success.form.fv', function(e) {
            e.preventDefault();
            var candidate = $('#candidate_id').val();
            var projectId = $('#ew_project_id').val();
            var width = $(document).width();
            var height = $(document).height();
            var url = "{{route('ew.accountStatusReportData')}}"+'?candidate='+candidate+'&projectId='+projectId;
            var myWindow = window.open(url, "", "width="+width+",height="+height);
            $('#preview_button').removeAttr('disabled').removeClass('disabled');
        });
    });
</script>