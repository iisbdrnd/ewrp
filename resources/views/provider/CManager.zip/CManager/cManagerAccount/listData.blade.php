<div class="form-inline">
    <div class="row datatables_header">
        <div class="col-md-6 col-xs-12">
            <div class="input-group">
                <input name="search" event="enter" class="data-search form-control" id="search-input" value="{{@$search}}" kl_virtual_keyboard_secure_input="on" placeholder="Search">
                <span class="input-group-btn"><button name="search" event="click" valueFrom="#search-input" class="data-search btn btn-primary" type="button">Go</button></span>
            </div>
        </div>
        <div class="col-md-6 col-xs-12">
            @include("perPageBox")
        </div>
    </div>
</div>
<div id=myTabContent2 class=tab-content>
    <div class="tab-pane fade active in" id=home2>
        <div class="form-inline">
            <table cellspacing="0" class="responsive table table-striped table-bordered">
                <thead>
                    <tr>
                        <th width="5%">No.</th>
                        <th data="1">Name</th>
                        <th data="2" width="20%">Mobile</th>
                        <th data="3" width="20%">Email</th>
                        <th data="5" width="15%">Create Date</th>
                        <th data="8" width="10%" class="tac">Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Create Date</th>
                        <th class="tac">Action</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php $paginate = $content_manager_accounts; ?>
                @if(count($content_manager_accounts)>0)
                    @foreach($content_manager_accounts as $content_manager_account)
                        <tr>
                            <td>{{$sn++}}</td>
                            <td>{{$content_manager_account->account_name}}</td>
                            <td>{{$content_manager_account->mobile}}</td>
                            <td>{{$content_manager_account->email}}</td>
                            <td>{{Helper::dateTime($content_manager_account->created_at)}}</td>
                            <td class="tac">
                                <!-- COURSES LIST -->
                                <button url="cm_agreement_list?account={{$content_manager_account->id}}&&status=0" class="go-btn hand btn btn-success btn-xs mt5" type="button">Courses</button>
                            </td>

                        </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="10" class="emptyMessage">Empty</td>
                    </tr>
                @endif
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    @include("pagination")
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $(".select2").select2();
    });
</script>
