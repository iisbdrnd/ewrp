@include("urlParaMeter")
<?php $tableTitle = "Content manager accounts"; $loadUrl = "cm_accounts_list"; ?>
@include("dataListFrame")
