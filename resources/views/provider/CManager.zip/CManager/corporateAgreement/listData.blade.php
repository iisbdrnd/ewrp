<div class="form-inline">
    <div class="row datatables_header">
        <div class="col-md-3 col-xs-12">
            <div class="input-group">
                <input name="search" event="enter" class="data-search form-control" id="search-input" value="{{@$search}}" kl_virtual_keyboard_secure_input="on" placeholder="Search">
                <span class="input-group-btn"><button name="search" event="click" valueFrom="#search-input" class="data-search btn btn-primary" type="button">Go</button></span>
            </div>
        </div>
        <div class="col-md-3 col-xs-12 pl0">
            <select name="account" event="change" class="data-search form-control select2" style="width: 100%;">
                <option value=''> All Accounts</option>
                @foreach($accounts as $accounts)
                <option value="{{$accounts->id}}" @if($accounts->id==@$cm_account){{'selected'}}@endif>{{$accounts->account_name}}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3 col-xs-12 pl0">
            <select name="status" event="change" class="data-search form-control select2" style="width: 100%;">
                <option value=3> All Status</option>
                @foreach($approval_status as $approval_status)
                <option value="{{$approval_status->status_id}}" @if($approval_status->status_id==$status){{'selected'}}@endif>{{$approval_status->status_name}}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3 col-xs-12">
            @include("perPageBox")
        </div>
    </div>
</div>
<div id=myTabContent2 class=tab-content>
    <div class="tab-pane fade active in" id=home2>
        <div class="form-inline">
            <table cellspacing="0" class="responsive table table-striped table-bordered">
                <thead>
                    <tr>
                        <th width="5%">No.</th>
                        <th data="1">Course</th>
                        <th data="2" width="15%">Subject</th>
                        <th data="3" width="10%">Account</th>
                        <th data="5" width="12%">Request Date</th>
                        <th data="6" width="12%">Final Price</th>
                        <th data="7" width="12%">Request Price</th>
                        <th data="8" width="5%">Status</th>
                        <th data="8" width="10%" class="tac">Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Course</th>
                        <th>Subject</th>
                        <th>Account</th>
                        <th>Request Date</th>
                        <th>Final Price</th>
                        <th>Request Price</th>
                        <th>Status</th>
                        <th class="tac">Action</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php $paginate = $agreementCourses; ?>
                @if(count($agreementCourses)>0)
                    @foreach($agreementCourses as $agreementCourse)
                        <tr>
                            <td>{{$sn++}}</td>
                            <td>{{$agreementCourse->course_name}}</td>
                            <td>{{$agreementCourse->subject_name}}</td>
                            <td>{{$agreementCourse->account_name}}</td>
                            <td>{{Helper::dateTime($agreementCourse->created_at)}}</td>
                            <td>
                                {{$agreementCourse->final_price.' '.$agreementCourse->html_code}}
                            </td>
                            <td>
                                {{$agreementCourse->requested_price.' '.$agreementCourse->html_code}}
                            </td>
                            <td class="tac">
                                <button  view-type="modal" modal-size="medium" url="corporateCourseAgreementApproval/{{$agreementCourse->id}}/{{$agreementCourse->course_id}}" class="add-btn hand btn @if($agreementCourse->approval_status==0){{'btn-danger'}}@elseif($agreementCourse->approval_status==2){{'btn-warning'}}@else{{'btn-success'}}@endif btn-xs mt5" type="button">@if($agreementCourse->approval_status==0){{'Pending'}}@elseif($agreementCourse->approval_status==1){{'Approved'}}@else{{'Decline'}}@endif</button>
                            </td>
                            <td class="tac">
                                <!-- COURSE DETAILS -->
                                <!-- 1=Corporate agreement -->
                                <a href="course_details/{{$agreementCourse->course_id}}/{{$agreementCourse->agreement_id}}/{{$status}}/1/corporate_agreement" class="ajax-link hand btn btn-success btn-xs">Details</a><br>
                            </td>

                        </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="10" class="emptyMessage">Empty</td>
                    </tr>
                @endif
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    @include("pagination")
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $(".select2").select2();
    });
</script>
