<?php $panelTitle = "Agreement Status"; ?>
@include("panelStart")
<form type="update" callback="agreementStatus" action="{{route('provider.cManager.corporateCourseAgreementApprovalAction')}}" panelTitle="{{$panelTitle}}" class="form-load form-horizontal group-border stripped" data-fv-excluded="">
    {{csrf_field()}}
    <div class="form-group">
        <div class="col-lg-12 col-md-12 approval_course_info">
            <table class="table table-hover">
                <tbody>
                    <tr style="border: none;">
                        <td style="border: none;" width="31%"><strong>Content Provider</strong></td>
                        <td style="border: none;" width="69%"><strong>:</strong> {{$content_provider}}</td>
                    </tr>
                    <tr>
                        <td><strong>Corporate Account</strong></td>
                        <td><strong>:</strong> {{$corporate_account}}</td>
                    </tr>
                    <tr>
                        <td><strong>Session</strong></td>
                        <td><strong>:</strong> {{$session}}</td>
                    </tr>
                    <tr>
                        <td><strong>Batch</strong></td>
                        <td><strong>:</strong> {{$batch}}</td>
                    </tr>
                    <tr>
                        <td><strong>Subject</strong></td>
                        <td><strong>:</strong> {{$subject_name}}</td>
                    </tr>
                    <tr>
                        <td><strong>Course</strong></td>
                        <td><strong>:</strong> {{$courseDetails->course_name}}</td>
                    </tr>
                    <tr>
                        <td><strong>Duration</strong></td>
                        <td><strong>:</strong> {{$corCourseAgreementDetails->customize_course_duration}}@if($corCourseAgreementDetails->customize_course_duration>0){{' Days'}}@else{{' Day'}}@endif</td>
                    </tr>
                    <tr>
                        <td><strong>Start Date</strong></td>
                        <td><strong>:</strong> {{Helper::dateTime($corCourseAgreementDetails->course_effective_start_date)}}</td>
                    </tr>
                    <tr>
                        <td><strong>End Date</strong></td>
                        <td><strong>:</strong> {{Helper::dateTime($corCourseAgreementDetails->course_effective_end_date)}}</td>
                    </tr>
                    <tr>
                        <td><strong>Requested Price</strong></td>
                        <td><strong>:</strong> {{$agreementApprovalDetails->requested_price.' '.$currency}}</td>
                    </tr>
                    <tr>
                        <td><strong>Final Price</strong></td>
                        <td><strong>:</strong> {{$agreementApprovalDetails->final_price.' '.$currency}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="form-group">
        <input type="hidden" name="agreement_approval_id" value="{{$agreement_approval_id}}">
        <input type="hidden" name="corporate_course_agreement_id" value="{{$corCourseAgreementDetails->id}}">
        <input type="hidden" name="course_id" value="{{$course_id}}">
        <input type="hidden" name="corporate_account_id" value="{{$agreementApprovalDetails->corporate_account_id}}">
        <input type="hidden" name="content_provider_account_id" value="{{$agreementApprovalDetails->content_provider_account_id}}">
        <label for="approval_status" class="col-lg-4 col-md-4 control-label pr24 required">Status <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <select required name="approval_status" id="approval_status" data-fv-icon="false" class="form-control ml0">
                @foreach($approval_status as $status)
                <option value="{{$status->status_id}}" @if($status->status_id==$agreementApprovalDetails->approval_status){{'selected'}}@endif>{{$status->status_name}}</option>
                @endforeach
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="final_price" class="col-lg-4 col-md-4 control-label pr24">Final Price <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <div class=input-group>
                <input required id="final_price" name="final_price"  placeholder="e.g.60,000" class="form-control"  data-fv-regexp="true"
                data-fv-regexp-regexp="^[0-9+\s\.]+$"
                data-fv-greaterthan="true" data-fv-greaterthan-value="1"
                data-fv-regexp-message="Final price can consist of number only" value="{{$agreementApprovalDetails->final_price}}">
                <span class="input-group-addon">{{$currency}}</span>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label for="approval_remarks" class="col-lg-4 col-md-4 control-label pr24">Remarks <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <textarea name="approval_remarks" class="form-control" rows=3>{{$agreementApprovalDetails->approval_remarks}}</textarea>
        </div>
    </div>

</form>
@include("panelEnd")

<script type="text/javascript">
    $(document).ready(function() {
        $("#approval_status").select2({
            placeholder: "Select"
        });
    });

    function agreementStatus(data) {
        bootbox.hideAll();
    }
</script>