@include("urlParaMeter")
<?php $tableTitle = "Corporate agreement list"; $loadUrl = "corporate_agreement_list"; ?>
@include("dataListFrame")
