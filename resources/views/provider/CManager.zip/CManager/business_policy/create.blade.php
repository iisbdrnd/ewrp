<?php $panelTitle = "Business Policy For Content Manager"; ?>
@include("panelStart")
<form type="update" panelTitle="{{$panelTitle}}" class="form-load form-horizontal group-border stripped" data-fv-excluded="" action="{{route('provider.cManager.business_policy_action')}}">
    {{csrf_field()}}
    <div class="form-group has-feedback">
        <label class="col-lg-4 col-md-4 control-label required">Provider Share</label>
        <div class="col-lg-6 col-md-6">
            <div class="input-group">
                <input data-fv-icon="false" name="provider_share" required placeholder="e.g.60" class="form-control" type="number" data-fv-greaterthan="true" data-fv-greaterthan-value="1" data-fv-lessthan="true" data-fv-lessthan-value="100" value="{{@$business_policy->provider_share}}">
                <span class="input-group-addon">%</span>
            </div>
        </div>
    </div>
    <div class="form-group has-feedback">
        <label class="col-lg-4 col-md-4 control-label required">Content Manager Share</label>
        <div class="col-lg-6 col-md-6">
            <div class="input-group">
                <input data-fv-icon="false" name="content_manager_share" required placeholder="e.g.40" class="form-control" type="number" data-fv-greaterthan="true" data-fv-greaterthan-value="1" data-fv-lessthan="true" data-fv-lessthan-value="100" value="{{@$business_policy->content_manager_share}}">
                <span class="input-group-addon">%</span>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="col-lg-offset-4">
            <button type="submit" class="btn btn-success ml15">Policy Create</button>
        </div>
    </div>
</form>
@include("panelEnd")

