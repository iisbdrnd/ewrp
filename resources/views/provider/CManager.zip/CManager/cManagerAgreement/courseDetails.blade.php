<link type="text/css" rel="stylesheet" href="{!! asset('public/css/custom_course_details.css') !!}" />
<style type="text/css">
    #content .contentwrapper {
        padding-top: 0px; 
    }
    .course-details-main {
        padding: 28px 0 0;
    }
    .course-details h2 {
        margin-bottom: 0px; 
    }
    .course-details h2 {
        padding-top: 0px;
        margin-top: 0px;
    }
    .course-details {
        margin-left: -26px;
    }
    .container {
        width: 100%;
    }
</style>
<div class="course-details">
    <div class="course-details-main">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="course-img">
                        <img class=" " src="{{url('public/web/images/banner_378x225.jpg')}}" alt="">
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="course-overview">
                        <h2>{{$courseDetails->course_name}}
                            @if($courseDetails->social_media_share==1)
                                <div class="ssk-xs ssk-group ssk-rounded pull-right" style="margin-right:100px;">
                                    @if($sclConfig->facebook==1)<a href="#" class="ssk ssk-facebook"></a>@endif
                                    @if($sclConfig->twitter==1)<a href="#" class="ssk ssk-twitter"></a>@endif
                                    @if($sclConfig->google_plus==1)<a href="#" class="ssk ssk-google-plus"></a>@endif
                                    @if($sclConfig->linkedin==1)<a href="#" class="ssk ssk-linkedin"></a>@endif
                                    @if($sclConfig->pinterest==1)<a href="#" class="ssk ssk-pinterest"></a>@endif
                                </div>
                            @endif
                        </h2>
                        <p>Created by <a href="#">{{$account_name}} </a></p>
                        <p class="mt10">Course Duration 
                            @if($type==0)
                                {{$courseDetails->course_duration}} @if($courseDetails->course_duration>1){{'Days'}}@else{{'Day'}}@endif
                            @elseif($type==1 || $type==2)
                                {{$agreementDetails->customize_course_duration}} @if($agreementDetails->customize_course_duration>1){{'Days'}}@else{{'Day'}}@endif
                            @endif
                        </p>
                        
                        <p>
                            @if($type==0) 
                            Effort Time {{$courseDetails->course_effort}} Days 
                            <span class="enroll-price-view" style="font-size: 20px; margin-left: 100px !important; margin-top: 0px !important;"><b>{{$courseDetails->course_price}}</b> {{$currency}}</span>
                            @else
                                {{Helper::dateMdY($agreementDetails->course_effective_start_date).' To '.Helper::dateMdY($agreementDetails->course_effective_end_date)}}<span class="enroll-price-view" style="font-size: 20px; margin-left: 100px !important; margin-top: 0px !important;"><b>{{$approvalDetails->final_price}}</b> {{$currency}}</span>
                            @endif

                            <button type="button" href="{{$url}}?status={{$status}}" class="ajax-link btn btn-default ml20 hand" style="border-radius:5px;"><i class="s12 icomoon-icon-reply-2 mr5"></i>Back to list</button>
                        </p>
                        @if($type>0)
                        <p>Trainee Capacity : {{$agreementDetails->trainee}}</p>
                        @endif

                        <p>Last updated
                            <?php
                                $lastUpdate = DateTime::createFromFormat('Y-m-d H:i:s', @$courseDetails->updated_at);
                                $lastUpdate = $lastUpdate->format('M d, Y');
                            ?>
                            {{$lastUpdate}}
                        </p>
                        <div class="clearfix"></div>
                        <div class="course-info">
                            <div class="course-box">
                                <div class="icon"><i class="fa fa-file"></i></div>
                                <p>@if(!empty($totalModules)){{$totalModules}}@endif Modules</p>
                            </div>
                            <div class="course-box">
                                <div class="icon"><i class="fa fa-exclamation"></i></div>
                                <p>@if(!empty($totalModules)){{$totalModules+1}}@endif Exams</p>
                            </div>
                            <div class="course-box">
                                <div class="icon"><i class="fa fa-file-text-o"></i></div>
                                <p>{{$totalFiles}} Files</p>
                            </div>
                            <div class="course-box">
                                <div class="icon"><i class="fa fa-video-camera"></i></div>
                                <p>{{$totalVideos}} videos</p>
                            </div>
                            <div class="course-box">
                                <div class="icon"><i class="fa fa-mortar-board"></i></div>
                                <p>{{$courseDetails->total_enrolled}} Trainee</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="clearfix"></div>
        <div class="info">
            <h4>Course Overview</h4>
            <p style="text-align: justify;">
                {{$courseDetails->course_details}}
            </p>
        </div>
        @if($courseDetails->course_mode==1)
        <div class="info">
            <h4 class="mb0">{{$courseDetails->course_name}}</h4>
        </div>
        <div class="syllabus">
            @foreach($courseModules as $courseModule)
            <div class="syllabus-box">
                <div class="syllabus-title"> </div>
                <div class="syllabus-view">
                    <div class="main-point">{{$courseModule->module_name}}</div>
                    <div class="point-list disabled">
                        <ul>
                            @foreach($courseModule->contents as $content)
                                <li><a href='#'><i class="fa @if($content->type==1){{'fa-book'}}@elseif($content->type==2){{'fa-play'}}@elseif($content->type==3){{'fa-file-powerpoint-o'}}@elseif($content->type==4){{'fa-file-pdf-o'}}@endif"></i> {{$content->title}}</a></li>
                            @endforeach
                            @if($courseModule->exam==1)
                                <li class="exam"><a href='#'><i class="fa fa-edit"></i> Take exam</a></li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
            @endforeach
            @if(@$courseExam->exam==1)
            <div class="syllabus-box">
                <div class="syllabus-title">  </div>
                <div class="syllabus-view reUnderline">
                    <div class="main-point exam">
                        <a class="disabled" style="cursor:default;">Course Exam</a>
                    </div>
                </div>
            </div>
            @endif
        </div>
    @else
        <div class="info" style="padding: 6px 0px!important;">
            <h2 class="mb0">{{$courseDetails->course_name}}</h2>
        </div>
        @foreach($packageCourses as $packageCourse)
            <div class="info" style="padding: 6px 0px!important;">
                <h4 class="mb0">{{$packageCourse->course_name}}</h4>
            </div>
            <div class="syllabus" >
                @foreach($packageCourse->courModule as $courseModule)
                <div class="syllabus-box">
                    <div class="syllabus-title">  </div>
                    <div class="syllabus-view">
                        <div class="main-point">{{$courseModule->module_name}}</div>
                        <div class="point-list disabled">
                            <ul>
                                <li><a href='#'><i class="fa fa-book"></i> Reading Module</a></li>
                                @foreach($courseModule->contentVideos as $courseContent)
                                    <li><a href='javascript:void(0)'><i class="fa fa-play"></i> {{$courseContent->videoTitle}} </a></li>
                                @endforeach

                                @foreach($courseModule->contentAttFiles as $courseContent)
                                    <li><a href='javascript:void(0)'><i class="fa fa-file-pdf-o"></i> {{$courseContent->attachment_real_name}}</a></li>
                                @endforeach
                                <li class="exam"><a href='#'><i class="fa fa-edit"></i> Take exam</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                @endforeach
                <div class="syllabus-box">
                    <div class="syllabus-title">  </div>
                    <div class="syllabus-view reUnderline">
                        <div class="main-point exam">
                            <a class="disabled" style="cursor:default;">Course Exam</a>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
        @endif
    </div>
</div>

