@include("urlParaMeter")
<?php $tableTitle = "Content provider agreement list"; $loadUrl = "cm_agreement_list"; ?>
@include("dataListFrame")
