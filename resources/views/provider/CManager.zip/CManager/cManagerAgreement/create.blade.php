<?php $panelTitle = "Create Session"; ?>
@include("panelStart")
<form type="create" panelTitle="{{$panelTitle}}" class="form-load form-horizontal group-border stripped" data-fv-excluded="">
    {{csrf_field()}}
    <div class="form-group">
        <label class="col-lg-2 col-md-3 control-label required">Corporate Account</label>
        <div class="col-lg-10 col-md-9">
            <select required id="account_id" name="account_id" data-fv-icon="false" class="select2 form-control ml0">
                <option value=""></option>
                @foreach($accounts as $accounts)
                <option value="{{$accounts->id}}">{{$accounts->account_name}}</option>
                @endforeach
            </select>
        </div>
    </div>
    <div class="form-group">
        <label class="col-lg-2 col-md-3 control-label required">Session Name</label>
        <div class="col-lg-10 col-md-9">
            <input required name="session_name" class="form-control">
        </div>
    </div>
    <div class="form-group">
        <div class="col-lg-offset-2">
            <button type="submit" class="btn btn-default ml15">Create</button>
        </div>
    </div>
</form>
@include("panelEnd")

<script type="text/javascript">
    $(document).ready(function() {
        $('#account_id').select2({placeholder: "Select Account"});
    });
</script>
