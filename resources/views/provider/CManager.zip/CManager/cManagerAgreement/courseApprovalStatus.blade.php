<?php $panelTitle = "Agreement Status"; ?>
<style type="text/css">
    .approval_course_info{
        font-size: 14px!important;
        dt {
            line-height: 50px!important;
        }
    }
</style>
@include("panelStart")
<form type="update" callback="agreementStatus" action="{{route('provider.cManager.courseApprovalStatusAction')}}" panelTitle="{{$panelTitle}}" class="form-load form-horizontal group-border stripped" data-fv-excluded="">
    {{csrf_field()}}
    <div class="form-group">
        <div class="col-lg-12 col-md-12 approval_course_info">
            <!-- <dl class="dl-horizontal mb0">
                <dt><span class="text-muted"><strong>Account: </strong></span></dt>
                <dd>{{$account->account_name}}</dd>
                <dt><span class="text-muted"><strong>Course: </strong></span></dt>
                <dd>{{$courseDetails->course_name}}</dd>
                <dt><span class="text-muted"><strong>Subject: </strong></span></dt>
                <dd>{{$subject_name}}</dd>
                <dt><span class="text-muted"><strong>Price: </strong></span></dt>
                <dd>{{$courseDetails->course_price.' '.$currency}}</dd>
                <dt><span class="text-muted"><strong>Duration: </strong></span></dt>
                <dd>{{$courseDetails->course_duration}}@if($courseDetails->course_duration>0){{' Days'}}@else{{' Day'}}@endif</dd>
                <dt><span class="text-muted"><strong>Course Effort: </strong></span></dt>
                <dd>{{$courseDetails->course_effort}}</dd>
                <dt><span class="text-muted"><strong>Provider Share: </strong></span></dt>
                <dd>{{$agreementDetails->active_provider_share.'%'}}</dd>
                <dt><span class="text-muted"><strong>Content Provider Share: </strong></span></dt>
                <dd>{{$agreementDetails->active_content_manager_share.'%'}}</dd>
                <dt><span class="text-muted"><strong>Request Content Provider Share: </strong></span></dt>
                <dd>{{$agreementDetails->negotiate_content_manager_share.'%'}}</dd>

            </dl> -->
            <table class="table table-hover">
                <tbody>
                    <tr style="border: none;">
                        <td style="border: none;" width="35%"><strong>Account</strong></td>
                        <td style="border: none;" width="65%"><strong>:</strong> {{$account->account_name}}</td>
                    </tr>
                    <tr>
                        <td><strong>Course</strong></td>
                        <td><strong>:</strong> {{$courseDetails->course_name}}</td>
                    </tr>
                    <tr>
                        <td><strong>Subject</strong></td>
                        <td><strong>:</strong> {{$subject_name}}</td>
                    </tr>
                    <tr>
                        <td><strong>Price</strong></td>
                        <td><strong>:</strong> {{$courseDetails->course_price.' '.$currency}}</td>
                    </tr>
                    <tr>
                        <td><strong>Duration</strong></td>
                        <td><strong>:</strong> {{$courseDetails->course_duration}}@if($courseDetails->course_duration>0){{' Days'}}@else{{' Day'}}@endif</td>
                    </tr>
                    <tr>
                        <td><strong>Course Effort</strong></td>
                        <td><strong>:</strong> {{$courseDetails->course_effort}}</td>
                    </tr>
                    <tr>
                        <td><strong>Provider Share</strong></td>
                        <td><strong>:</strong> {{$agreementDetails->active_provider_share.'%'}}</td>
                    </tr>
                    <tr>
                        <td><strong>Content Provider Share</strong></td>
                        <td><strong>:</strong> {{$agreementDetails->active_content_manager_share.'%'}}</td>
                    </tr>
                    <tr>
                        <td><strong>Requested Content Provider Share</strong></td>
                        <td><strong>:</strong> {{$agreementDetails->negotiate_content_manager_share.'%'}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="form-group">
        <input type="hidden" name="account_id" value="{{$account->id}}">
        <input type="hidden" name="cm_agreement_id" value="{{$cm_agreement_id}}">
        <input type="hidden" name="course_id" value="{{$course_id}}">
        <input type="hidden" name="active_provider_share" value="{{$agreementDetails->active_provider_share}}">
        <input type="hidden" name="active_content_manager_share" value="{{$agreementDetails->active_content_manager_share}}">
        <label for="approval_status" class="col-lg-4 col-md-4 control-label pr24 required">Status <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <select required name="approval_status" id="approval_status" data-fv-icon="false" class="form-control ml0">
                @foreach($approval_status as $status)
                <option value="{{$status->status_id}}" @if($status->status_id==$agreementDetails->approval_status){{'selected'}}@endif>{{$status->status_name}}</option>
                @endforeach
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="final_content_provider_share" class="col-lg-4 col-md-4 control-label pr24">Final Content Provider Share <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <div class=input-group>
                <input required id="final_content_provider_share" name="final_content_provider_share"  placeholder="e.g.40" class="form-control"  data-fv-regexp="true"
                data-fv-regexp-regexp="^[0-9+\s\.]+$"
                data-fv-greaterthan="true" data-fv-greaterthan-value="1"
                data-fv-regexp-message="Profit share can consist of number only" value="{{$agreementDetails->active_content_manager_share}}">
                <span class="input-group-addon">%</span>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label for="approval_remarks" class="col-lg-4 col-md-4 control-label pr24">Remarks <strong>:</strong> </label>
        <div class="col-lg-8 col-md-8 pl0">
            <textarea name="approval_remarks" class="form-control" rows=3>{{@$agreementDetails->approval_remarks}}</textarea>
        </div>
    </div>

</form>
@include("panelEnd")

<script type="text/javascript">
    $(document).ready(function() {
        $("#approval_status").select2({
            placeholder: "Select"
        });
    });

    function agreementStatus(data) {
        bootbox.hideAll();
    }
</script>