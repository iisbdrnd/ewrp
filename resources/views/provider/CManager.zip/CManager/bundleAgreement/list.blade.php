@include("urlParaMeter")
<?php $tableTitle = "Bundle agreement list"; $loadUrl = "bundle_agreement_list"; ?>
@include("dataListFrame")
